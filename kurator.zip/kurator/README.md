# Spotify Kurator Frontend

React UI built with Vite and Tailwind CSS. It communicates with `server.js` to fetch playlist details from Spotify and get recommendations from OpenAI.

Use `npm run dev` during development or build the app with `npm run build`.
